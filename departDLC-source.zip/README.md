# departDLC — Fabric Client Mod for Minecraft 1.21.4

**Watermark:** `departDLC by @departface`

## Сборка

### Требования
- Java 21+
- Gradle 8+

### Как собрать .jar
```bash
./gradlew build
```
Готовый `.jar` появится в папке `build/libs/departDLC-1.0.0.jar`

### Установка
1. Установи [Fabric Loader](https://fabricmc.net/use/installer/) для Minecraft 1.21.4
2. Скачай [Fabric API](https://modrinth.com/mod/fabric-api)
3. Положи `departDLC-1.0.0.jar` и `fabric-api.jar` в папку `mods/`
4. Запускай игру!

## Управление
- **RSHIFT** — открыть ClickGUI
- **ЛКМ** на модуле — включить/выключить
- **ПКМ** на модуле — раскрыть настройки
- **СКМ** на модуле — назначить клавишу

## Модули

### Combat (Бой)
- **KillAura** — Range, Speed, HitChance, Rotation, Criticals, ThroughWalls, MultiTarget, TargetPriority, AntiCheat
- **TriggerBot** — Delay, OnlyCrits, OnlyWhileHoldingLMB, Randomization
- **AimAssist** — HorizontalSpeed, VerticalSpeed, MaxAngle, Distance, SilentAim
- **ShieldBreaker** — KeyBind(X), DelayTicks, OnlyWhenBlocking, AxeSlot
- **Velocity** — Horizontal, Vertical, Mode

### Movement (Движение)
- **Sprint, NoFall, Speed, Fly, LongJump, Step, NoSlowdown**

### Render (Визуалы)
- **ESP, Tracers, Chams, Nametags, FullBright, Crosshair**
- **Watermark** — `departDLC by @departface`
- **Arraylist, ArmorHUD, Coords, TargetHUD, KeyStrokes**
- **HitboxViewer, AntiBlind, Zoom** (клавиша C)

### Exploit (Эксплойты)
- **Scaffold, AutoTool, AutoArmor, ChestStealer**
- **AntiBot, Disabler, Timer**
