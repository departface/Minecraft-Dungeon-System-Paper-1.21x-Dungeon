package com.departdlc.mixin;

import com.departdlc.DepartDLC;
import com.departdlc.feature.module.Module;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (action == 1) { // GLFW_PRESS
            for (Module module : DepartDLC.getInstance().getModuleManager().getModulesByCategory(
                    com.departdlc.feature.module.Category.COMBAT)) {
                if (module.getKey() == key) module.toggle();
            }
        }
    }
}
