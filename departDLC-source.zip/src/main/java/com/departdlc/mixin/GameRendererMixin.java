package com.departdlc.mixin;

import com.departdlc.DepartDLC;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void onRenderWorld(CallbackInfo ci) {
        // Render hook for departDLC modules
        DepartDLC.getInstance().getModuleManager().getModulesByCategory(
            com.departdlc.feature.module.Category.RENDER
        ).stream()
         .filter(m -> m.isState())
         .forEach(m -> m.onRender());
    }
}
