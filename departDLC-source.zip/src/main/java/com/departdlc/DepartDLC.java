package com.departdlc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import com.departdlc.feature.module.ModuleManager;
import com.departdlc.feature.ui.menu.GuiScreen;

public class DepartDLC implements ClientModInitializer {

    public static final String NAME = "departDLC";
    public static final String VERSION = "1.0.0";
    public static final String AUTHOR = "@departface";
    public static final String WATERMARK = "departDLC by @departface";

    private static DepartDLC INSTANCE;
    private ModuleManager moduleManager;

    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        moduleManager = new ModuleManager();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.departdlc.opengui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.departdlc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new GuiScreen());
                }
            }
            moduleManager.onTick();
        });

        System.out.println("[departDLC] Loaded " + NAME + " v" + VERSION + " by " + AUTHOR);
    }

    public static DepartDLC getInstance() { return INSTANCE; }
    public ModuleManager getModuleManager() { return moduleManager; }
}
