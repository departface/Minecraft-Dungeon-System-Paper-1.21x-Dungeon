package com.departdlc.feature.module.impl.combat;

import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;

public class ShieldBreaker extends Module {
    public final BindSetting keyBind = new BindSetting("KeyBind", 88); // X
    public final SliderSetting delayTicks = new SliderSetting("Delay Ticks", 5, 0, 20, 1);
    public final BooleanSetting onlyWhenBlocking = new BooleanSetting("OnlyWhenBlocking", true);
    public final ModeSetting axeSlot = new ModeSetting("Axe Slot", "HotbarOnly", "HotbarOnly", "InventorySearch");

    public ShieldBreaker() {
        super("ShieldBreaker", Category.COMBAT);
        addSetting(keyBind); addSetting(delayTicks);
        addSetting(onlyWhenBlocking); addSetting(axeSlot);
    }
}
