package com.departdlc.feature.module.impl.movement;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class NoSlowdown extends Module {
    public NoSlowdown() { super("NoSlowdown", Category.MOVEMENT); }
}
