package com.departdlc.feature.module.impl.combat;

import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;

public class TriggerBot extends Module {
    public final SliderSetting delay = new SliderSetting("Delay", 50, 0, 200, 1);
    public final BooleanSetting onlyCrits = new BooleanSetting("OnlyCrits", false);
    public final BooleanSetting onlyLMB = new BooleanSetting("OnlyWhileHoldingLMB", false);
    public final BooleanSetting randomization = new BooleanSetting("Randomization", true);

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
        addSetting(delay); addSetting(onlyCrits);
        addSetting(onlyLMB); addSetting(randomization);
    }
}
