package com.departdlc.feature.module.setting.impl;

import com.departdlc.feature.module.setting.Setting;

public class SliderSetting extends Setting {
    private float value, minimum, maximum, increment;

    public SliderSetting(String name, float defaultValue, float minimum, float maximum, float increment) {
        super(name);
        this.value = defaultValue;
        this.minimum = minimum;
        this.maximum = maximum;
        this.increment = increment;
    }

    public float get() { return value; }
    public float getMinimum() { return minimum; }
    public float getMaximum() { return maximum; }
    public float getIncrement() { return increment; }
    public void setValue(float value) { this.value = Math.max(minimum, Math.min(maximum, value)); }
}
