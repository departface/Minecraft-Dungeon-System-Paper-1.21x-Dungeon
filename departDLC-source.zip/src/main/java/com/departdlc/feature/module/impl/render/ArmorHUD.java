package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class ArmorHUD extends Module {
    public ArmorHUD() { super("ArmorHUD", Category.RENDER); }
}
