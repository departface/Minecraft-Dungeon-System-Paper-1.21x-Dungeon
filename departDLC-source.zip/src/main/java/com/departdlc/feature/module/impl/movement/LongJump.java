package com.departdlc.feature.module.impl.movement;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.SliderSetting;
public class LongJump extends Module {
    public final SliderSetting power = new SliderSetting("Power", 1.5f, 1.0f, 2.0f, 0.1f);
    public LongJump() { super("LongJump", Category.MOVEMENT); addSetting(power); }
}
