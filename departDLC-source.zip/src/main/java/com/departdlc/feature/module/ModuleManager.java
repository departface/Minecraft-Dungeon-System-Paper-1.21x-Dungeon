package com.departdlc.feature.module;

import com.departdlc.feature.module.impl.combat.*;
import com.departdlc.feature.module.impl.movement.*;
import com.departdlc.feature.module.impl.render.*;
import com.departdlc.feature.module.impl.exploit.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Combat
        modules.add(new KillAura());
        modules.add(new TriggerBot());
        modules.add(new AimAssist());
        modules.add(new ShieldBreaker());
        modules.add(new Velocity());

        // Movement
        modules.add(new Sprint());
        modules.add(new NoFall());
        modules.add(new Speed());
        modules.add(new Fly());
        modules.add(new LongJump());
        modules.add(new Step());
        modules.add(new NoSlowdown());

        // Render
        modules.add(new ESP());
        modules.add(new Tracers());
        modules.add(new Chams());
        modules.add(new Nametags());
        modules.add(new FullBright());
        modules.add(new Crosshair());
        modules.add(new Watermark());
        modules.add(new Arraylist());
        modules.add(new ArmorHUD());
        modules.add(new Coords());
        modules.add(new TargetHUD());
        modules.add(new KeyStrokes());
        modules.add(new HitboxViewer());
        modules.add(new AntiBlind());
        modules.add(new Zoom());

        // Exploit
        modules.add(new Scaffold());
        modules.add(new AutoTool());
        modules.add(new AutoArmor());
        modules.add(new ChestStealer());
        modules.add(new AntiBot());
        modules.add(new Disabler());
        modules.add(new Timer());
    }

    public void onTick() {
        modules.stream().filter(Module::isState).forEach(Module::onTick);
    }

    public Module getModule(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public List<Module> getModulesByCategory(Category category) {
        return modules.stream().filter(m -> m.getCategory() == category).toList();
    }
}
