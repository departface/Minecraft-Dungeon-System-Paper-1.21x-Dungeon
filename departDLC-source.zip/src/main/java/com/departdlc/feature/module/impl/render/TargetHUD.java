package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class TargetHUD extends Module {
    public TargetHUD() { super("TargetHUD", Category.RENDER); }
}
