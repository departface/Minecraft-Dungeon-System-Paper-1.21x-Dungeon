package com.departdlc.feature.module.setting.impl;

import com.departdlc.feature.module.setting.Setting;

public class RangeSetting extends Setting {
    private float minValue, maxValue, minimum, maximum, increment;

    public RangeSetting(String name, float minValue, float maxValue, float minimum, float maximum, float increment) {
        super(name);
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.minimum = minimum;
        this.maximum = maximum;
        this.increment = increment;
    }

    public float getMinValue() { return minValue; }
    public float getMaxValue() { return maxValue; }
    public float getMinimum() { return minimum; }
    public float getMaximum() { return maximum; }
    public float getIncrement() { return increment; }
    public void setMinValue(float v) { this.minValue = Math.max(minimum, Math.min(maxValue, v)); }
    public void setMaxValue(float v) { this.maxValue = Math.max(minValue, Math.min(maximum, v)); }
}
