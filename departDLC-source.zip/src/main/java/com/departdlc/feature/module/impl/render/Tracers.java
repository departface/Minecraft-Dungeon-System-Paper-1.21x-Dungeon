package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;
public class Tracers extends Module {
    public final BooleanSetting colorByHealth = new BooleanSetting("Color by Health", false);
    public final SliderSetting thickness = new SliderSetting("Thickness", 1, 1, 5, 1);
    public Tracers() { super("Tracers", Category.RENDER); addSetting(colorByHealth); addSetting(thickness); }
}
