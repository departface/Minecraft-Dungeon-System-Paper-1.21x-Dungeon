package com.departdlc.feature.module.impl.combat;

import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;

public class KillAura extends Module {
    public final SliderSetting range = new SliderSetting("Range", 3.0f, 2.0f, 6.0f, 0.1f);
    public final SliderSetting speed = new SliderSetting("Speed", 10, 1, 15, 1);
    public final SliderSetting hitChance = new SliderSetting("Hit Chance", 100, 0, 100, 1);
    public final ModeSetting rotation = new ModeSetting("Rotation", "Silent", "None", "Vertical", "Horizontal", "Silent");
    public final ModeSetting criticals = new ModeSetting("Criticals", "SmartCrits", "Off", "OnlyCrits", "SmartCrits");
    public final BooleanSetting throughWalls = new BooleanSetting("Through Walls", false);
    public final BooleanSetting multiTarget = new BooleanSetting("Multi Target", false);
    public final ModeSetting targetPriority = new ModeSetting("Target Priority", "Distance", "Distance", "Health", "Angle");
    public final ModeSetting antiCheat = new ModeSetting("AntiCheat Bypass", "Grim", "Grim", "Intave", "AAC");

    public KillAura() {
        super("KillAura", Category.COMBAT);
        addSetting(range); addSetting(speed); addSetting(hitChance);
        addSetting(rotation); addSetting(criticals);
        addSetting(throughWalls); addSetting(multiTarget);
        addSetting(targetPriority); addSetting(antiCheat);
    }
}
