package com.departdlc.feature.module.impl.movement;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.ModeSetting;
public class NoFall extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Grim");
    public NoFall() { super("NoFall", Category.MOVEMENT); addSetting(mode); }
}
