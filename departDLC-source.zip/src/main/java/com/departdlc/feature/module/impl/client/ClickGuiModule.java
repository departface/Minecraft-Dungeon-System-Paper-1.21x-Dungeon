package com.departdlc.feature.module.impl.client;

import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.ModeSetting;
import net.minecraft.client.MinecraftClient;
import com.departdlc.feature.ui.menu.GuiScreen;

public class ClickGuiModule extends Module {
    public final ModeSetting guiStyle = new ModeSetting("GUI Style", "Classic", "Classic");

    public ClickGuiModule() {
        super("ClickGUI", Category.CLIENT);
        addSetting(guiStyle);
    }

    @Override
    public void onEnable() {
        MinecraftClient.getInstance().setScreen(new GuiScreen());
        setState(false);
    }
}
