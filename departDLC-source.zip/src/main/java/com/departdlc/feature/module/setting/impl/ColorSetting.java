package com.departdlc.feature.module.setting.impl;

import com.departdlc.feature.module.setting.Setting;
import java.awt.Color;

public class ColorSetting extends Setting {
    private Color color;
    private boolean alpha;

    public ColorSetting(String name, Color defaultColor, boolean alpha) {
        super(name);
        this.color = defaultColor;
        this.alpha = alpha;
    }

    public Color getColor() { return color; }
    public void setColor(Color color) { this.color = color; }
    public boolean isAlpha() { return alpha; }
}
