package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class Chams extends Module {
    public Chams() { super("Chams", Category.RENDER); }
}
