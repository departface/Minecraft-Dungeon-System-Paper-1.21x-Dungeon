package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;
import java.awt.Color;
public class Crosshair extends Module {
    public final ModeSetting shape = new ModeSetting("Shape", "Cross", "Dot", "Cross", "Circle");
    public final SliderSetting size = new SliderSetting("Size", 5, 1, 10, 1);
    public final ColorSetting color = new ColorSetting("Color", new Color(255, 255, 255), false);
    public Crosshair() { super("Crosshair", Category.RENDER); addSetting(shape); addSetting(size); addSetting(color); }
}
