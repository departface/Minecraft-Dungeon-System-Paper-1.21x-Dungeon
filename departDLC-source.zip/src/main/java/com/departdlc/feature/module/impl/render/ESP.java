package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;
import java.awt.Color;
public class ESP extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Box", "Box", "Outline", "Wireframe");
    public final ColorSetting color = new ColorSetting("Color", new Color(136, 153, 255), false);
    public final SliderSetting thickness = new SliderSetting("Thickness", 2, 1, 5, 1);
    public final SliderSetting opacity = new SliderSetting("Opacity", 80, 0, 100, 1);
    public ESP() { super("ESP", Category.RENDER); addSetting(mode); addSetting(color); addSetting(thickness); addSetting(opacity); }
}
