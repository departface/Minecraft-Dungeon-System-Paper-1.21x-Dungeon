package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;
import java.awt.Color;
public class Arraylist extends Module {
    public final ColorSetting color = new ColorSetting("Color", new Color(136, 153, 255), false);
    public final BooleanSetting sortByLength = new BooleanSetting("Sort by length", true);
    public Arraylist() { super("Arraylist", Category.RENDER); addSetting(color); addSetting(sortByLength); }
}
