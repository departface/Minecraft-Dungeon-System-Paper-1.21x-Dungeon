package com.departdlc.feature.module.impl.combat;

import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;

public class AimAssist extends Module {
    public final SliderSetting horizontalSpeed = new SliderSetting("Horizontal Speed", 50, 0, 100, 1);
    public final SliderSetting verticalSpeed = new SliderSetting("Vertical Speed", 50, 0, 100, 1);
    public final SliderSetting maxAngle = new SliderSetting("Max Angle", 30, 0, 90, 1);
    public final SliderSetting distance = new SliderSetting("Distance", 4.5f, 3, 6, 0.1f);
    public final BooleanSetting silentAim = new BooleanSetting("Silent Aim", false);

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
        addSetting(horizontalSpeed); addSetting(verticalSpeed);
        addSetting(maxAngle); addSetting(distance); addSetting(silentAim);
    }
}
