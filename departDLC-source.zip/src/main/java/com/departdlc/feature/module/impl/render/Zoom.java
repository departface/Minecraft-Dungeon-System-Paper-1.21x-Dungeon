package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;
public class Zoom extends Module {
    public final BindSetting keyBind = new BindSetting("KeyBind", 67); // C
    public final SliderSetting zoomFactor = new SliderSetting("Zoom Factor", 4.0f, 1.5f, 10.0f, 0.1f);
    public Zoom() { super("Zoom", Category.RENDER); addSetting(keyBind); addSetting(zoomFactor); }
}
