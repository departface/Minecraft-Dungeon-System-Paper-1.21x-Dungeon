package com.departdlc.feature.module.impl.movement;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;
public class Speed extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "BHop", "Strafe", "Grim");
    public final SliderSetting speed = new SliderSetting("Speed", 1.5f, 1.0f, 3.0f, 0.1f);
    public Speed() { super("Speed", Category.MOVEMENT); addSetting(mode); addSetting(speed); }
}
