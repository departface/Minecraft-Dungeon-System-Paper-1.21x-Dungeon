package com.departdlc.feature.module.impl.movement;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MOVEMENT); }
}
