package com.departdlc.feature.module;

import com.departdlc.feature.module.setting.Setting;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private boolean state = false;
    private int key = 0;
    private final List<Setting> settings = new ArrayList<>();

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected void addSetting(Setting setting) {
        settings.add(setting);
    }

    public void toggle() {
        state = !state;
        if (state) onEnable();
        else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRender() {}

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public boolean isState() { return state; }
    public void setState(boolean state) { this.state = state; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public List<Setting> getSettings() { return settings; }
}
