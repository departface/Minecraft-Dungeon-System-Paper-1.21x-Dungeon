package com.departdlc.feature.module.impl.combat;

import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.*;

public class Velocity extends Module {
    public final SliderSetting horizontal = new SliderSetting("Horizontal", 0, 0, 100, 1);
    public final SliderSetting vertical = new SliderSetting("Vertical", 0, 0, 100, 1);
    public final ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Reverse");

    public Velocity() {
        super("Velocity", Category.COMBAT);
        addSetting(horizontal); addSetting(vertical); addSetting(mode);
    }
}
