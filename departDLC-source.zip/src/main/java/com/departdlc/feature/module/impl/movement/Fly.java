package com.departdlc.feature.module.impl.movement;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.ModeSetting;
public class Fly extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Creative", "Glide", "Grim");
    public Fly() { super("Fly", Category.MOVEMENT); addSetting(mode); }
}
