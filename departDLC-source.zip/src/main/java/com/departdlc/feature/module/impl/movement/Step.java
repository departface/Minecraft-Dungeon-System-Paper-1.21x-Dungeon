package com.departdlc.feature.module.impl.movement;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.SliderSetting;
public class Step extends Module {
    public final SliderSetting height = new SliderSetting("Height", 1, 1, 2, 1);
    public Step() { super("Step", Category.MOVEMENT); addSetting(height); }
}
