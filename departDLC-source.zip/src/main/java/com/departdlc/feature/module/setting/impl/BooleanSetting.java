package com.departdlc.feature.module.setting.impl;

import com.departdlc.feature.module.setting.Setting;

public class BooleanSetting extends Setting {
    private boolean state;

    public BooleanSetting(String name, boolean defaultValue) {
        super(name);
        this.state = defaultValue;
    }

    public boolean isState() { return state; }
    public void set(boolean state) { this.state = state; }
}
