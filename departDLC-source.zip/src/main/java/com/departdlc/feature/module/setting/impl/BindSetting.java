package com.departdlc.feature.module.setting.impl;

import com.departdlc.feature.module.setting.Setting;

public class BindSetting extends Setting {
    private int key;

    public BindSetting(String name, int defaultKey) {
        super(name);
        this.key = defaultKey;
    }

    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
}
