package com.departdlc.feature.module.setting.impl;

import com.departdlc.feature.module.setting.Setting;
import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {
    private String selected;
    private final List<String> list;

    public ModeSetting(String name, String defaultValue, String... modes) {
        super(name);
        this.list = Arrays.asList(modes);
        this.selected = defaultValue;
    }

    public String getSelected() { return selected; }
    public List<String> getList() { return list; }
    public void setSelected(String selected) { this.selected = selected; }
}
