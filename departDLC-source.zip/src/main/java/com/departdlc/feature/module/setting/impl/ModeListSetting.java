package com.departdlc.feature.module.setting.impl;

import com.departdlc.feature.module.setting.Setting;
import java.util.*;

public class ModeListSetting extends Setting {
    private List<String> selected = new ArrayList<>();
    private final List<String> list;

    public ModeListSetting(String name, List<String> modes) {
        super(name);
        this.list = modes;
    }

    public List<String> getList() { return list; }
    public List<String> getSelected() { return selected; }
    public void setSelected(List<String> selected) { this.selected = selected; }
    public boolean isSelected(String s) { return selected.contains(s); }
}
