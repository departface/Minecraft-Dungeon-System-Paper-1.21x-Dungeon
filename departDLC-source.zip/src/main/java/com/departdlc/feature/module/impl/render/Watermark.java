package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.BooleanSetting;
public class Watermark extends Module {
    public static final String TEXT = "departDLC by @departface";
    public final BooleanSetting draggable = new BooleanSetting("Draggable", true);
    public Watermark() { super("Watermark", Category.RENDER); addSetting(draggable); }
}
