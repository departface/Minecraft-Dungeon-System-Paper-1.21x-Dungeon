package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class Coords extends Module {
    public Coords() { super("Coords", Category.RENDER); }
}
