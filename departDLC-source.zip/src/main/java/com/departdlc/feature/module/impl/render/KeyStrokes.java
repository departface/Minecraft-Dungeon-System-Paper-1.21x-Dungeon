package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class KeyStrokes extends Module {
    public KeyStrokes() { super("KeyStrokes", Category.RENDER); }
}
