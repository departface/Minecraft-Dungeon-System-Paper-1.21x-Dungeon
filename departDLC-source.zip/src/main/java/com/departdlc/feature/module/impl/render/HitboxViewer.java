package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class HitboxViewer extends Module {
    public HitboxViewer() { super("HitboxViewer", Category.RENDER); }
}
