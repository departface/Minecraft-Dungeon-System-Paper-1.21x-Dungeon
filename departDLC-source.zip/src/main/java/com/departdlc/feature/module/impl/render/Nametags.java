package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.BooleanSetting;
public class Nametags extends Module {
    public final BooleanSetting healthBar = new BooleanSetting("Health bar", true);
    public final BooleanSetting armorBar = new BooleanSetting("Armor bar", true);
    public final BooleanSetting distance = new BooleanSetting("Distance", true);
    public Nametags() { super("Nametags", Category.RENDER); addSetting(healthBar); addSetting(armorBar); addSetting(distance); }
}
