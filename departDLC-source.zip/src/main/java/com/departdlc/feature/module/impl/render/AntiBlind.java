package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
public class AntiBlind extends Module {
    public AntiBlind() { super("AntiBlind", Category.RENDER); }
}
