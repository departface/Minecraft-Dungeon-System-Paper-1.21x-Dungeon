package com.departdlc.feature.module.impl.render;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.impl.SliderSetting;
public class FullBright extends Module {
    public final SliderSetting gamma = new SliderSetting("Gamma", 5.0f, 1.0f, 10.0f, 0.1f);
    public FullBright() { super("FullBright", Category.RENDER); addSetting(gamma); }
}
