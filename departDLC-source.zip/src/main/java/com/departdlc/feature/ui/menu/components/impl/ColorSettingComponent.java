package com.departdlc.feature.ui.menu.components.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.ColorSetting;
import com.departdlc.feature.ui.menu.components.SettingComponent;

import java.awt.Color;

public class ColorSettingComponent extends SettingComponent {
    private final ColorSetting setting;
    private float x, y;
    private boolean picking;

    public ColorSettingComponent(Setting setting) {
        super(setting);
        this.setting = (ColorSetting) setting;
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;
        context.drawText(client.textRenderer, setting.getName(), (int)x, (int)(y + 2), 0xFFD4D6E1, false);
        Color c = setting.getColor();
        context.fill((int)(x + 70), (int)y, (int)(x + 110), (int)(y + 14), c.getRGB());
        if (picking && mouseX >= x + 70 && mouseX <= x + 110 && mouseY >= y && mouseY <= y + 14) {
            setting.setColor(sample(mouseX, mouseY));
        }
    }

    private Color sample(double mouseX, double mouseY) {
        float localX = (float) MathHelper.clamp(mouseX - (x + 70), 0, 40);
        float localY = (float) MathHelper.clamp(mouseY - y, 0, 14);
        float hue = localX / 40f;
        float sat = 0.4f + 0.6f * (1f - localY / 14f);
        return Color.getHSBColor(hue, sat, 1f);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        if (mouseButton == 0 && mouseX >= x + 70 && mouseX <= x + 110 && mouseY >= y && mouseY <= y + 14)
            picking = true;
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, double button) { picking = false; }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {}

    @Override
    public float getFullHeight() { return 18f; }
}
