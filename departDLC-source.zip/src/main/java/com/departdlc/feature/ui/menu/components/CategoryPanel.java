package com.departdlc.feature.ui.menu.components;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.gui.DrawContext;
import com.departdlc.feature.module.Category;
import com.departdlc.feature.module.ModuleManager;

import java.util.ArrayList;

import static com.departdlc.util.other.animation.Direction.BACKWARDS;
import static com.departdlc.util.other.animation.Direction.FORWARDS;

public class CategoryPanel {
    private final ArrayList<ModuleComponent> modules = new ArrayList<>();
    @Getter
    private Category category;
    @Getter @Setter
    private float y = 0, x = 0;

    private boolean closing = false;
    private boolean closeAnimationFinished = false;

    public CategoryPanel(Category category, float x, float y) {
        this.category = category;
        this.x = x;
        this.y = y;
        ModuleManager.modules.forEach(m -> {
            if (getCategory() == m.getCategory()) modules.add(new ModuleComponent(m));
        });
    }

    public void render(DrawContext context, int height, int mouseX, int mouseY, float partialTicks) {
        float scaledX = this.x;
        float scaledY = this.y;

        for (ModuleComponent m : modules) {
            height += m.extended ? (int) m.getHeight() : 0;
        }

        context.fill((int)scaledX, (int)scaledY, (int)(scaledX + 80), (int)(scaledY + 20), 0x99000000);
        context.drawText(client.textRenderer, category.getDisplayName(), (int)(scaledX + 5), (int)(scaledY + 6), 0xFFFFFFFF, false);

        if (!modules.isEmpty()) {
            context.fill((int)scaledX, (int)(scaledY + 22), (int)(scaledX + 80), (int)(scaledY + 22 + height), 0x88000000);
        }

        renderPanel(context, mouseX, mouseY, partialTicks);
    }

    public void setClosing(boolean closing) {
        this.closing = closing;
        if (closing) closeAnimationFinished = true;
    }

    public boolean isCloseAnimationFinished() {
        return closeAnimationFinished;
    }

    public void renderPanel(DrawContext context, int mouseX, int mouseY, float partialTicks) {
        if (!modules.isEmpty()) {
            float y2 = this.y + 23;
            for (ModuleComponent m : modules) {
                m.render(context, this.x, y2, mouseX, mouseY, partialTicks);
                y2 += 15 + (m.extended ? m.getHeight() : 0);
            }
        }
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        modules.forEach(m -> m.keyPressed(keyCode, scanCode, modifiers));
    }

    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        for (ModuleComponent m : modules) {
            m.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }

    public void mouseReleased(double mouseX, double mouseY, double state) {
        modules.forEach(m -> m.mouseReleased(mouseX, mouseY, state));
    }
}
