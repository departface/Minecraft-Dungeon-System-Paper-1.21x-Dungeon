package com.departdlc.feature.ui.menu.components.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.SliderSetting;
import com.departdlc.feature.ui.menu.components.SettingComponent;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class SliderSettingComponent extends SettingComponent {
    private final SliderSetting setting;
    private boolean click = false;
    private float x = 0, y = 0;

    public SliderSettingComponent(Setting s) {
        super(s);
        setting = (SliderSetting) s;
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;

        context.drawText(client.textRenderer, setting.getName(), (int)x, (int)(y + 2), 0xFFD4D6E1, false);
        context.drawText(client.textRenderer, "" + setting.get(), (int)(x + 66), (int)(y + 9), 0xFFD4D6E1, false);

        // Track
        context.fill((int)(x + 3), (int)(y + 10), (int)(x + 63), (int)(y + 14), 0xFF0C0C0C);

        // Fill
        float fillWidth = (setting.get() - setting.getMinimum()) / (setting.getMaximum() - setting.getMinimum()) * 60;
        context.fill((int)(x + 3), (int)(y + 10), (int)(x + 3 + fillWidth), (int)(y + 14), 0xFF5566CC);

        // Thumb
        context.fill((int)(x + 3 + fillWidth - 2), (int)(y + 8), (int)(x + 3 + fillWidth + 4), (int)(y + 16), 0xFFFFFFFF);

        if (click) {
            float value = (float) MathHelper.clamp(
                round((float)((mouseX - x - 3) / 60.0 * (setting.getMaximum() - setting.getMinimum()) + setting.getMinimum()), setting.getIncrement()),
                setting.getMinimum(), setting.getMaximum());
            setting.setValue(value);
        }
    }

    public static double round(double num, double increment) {
        double v = Math.round(num / increment) * increment;
        return new BigDecimal(v).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        if (mouseX >= x + 3 && mouseX <= x + 63 && mouseY >= y + 10 && mouseY <= y + 14 && mouseButton == 0)
            click = true;
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, double button) { click = false; }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {}

    @Override
    public float getFullHeight() { return 22f; }
}
