package com.departdlc.feature.ui.menu.components.impl;

import net.minecraft.client.gui.DrawContext;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.ModeListSetting;
import com.departdlc.feature.ui.menu.components.SettingComponent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ModeListSettingComponent extends SettingComponent {
    private final ModeListSetting setting;
    private float x = 0, y = 0, height = 0;

    public ModeListSettingComponent(Setting s) {
        super(s);
        setting = (ModeListSetting) s;
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;
        height = setting.getList().size() * 10 + 15;

        context.drawText(client.textRenderer, setting.getName(), (int)x, (int)(y - 1), 0xFFD4D6E1, false);

        float y2 = 5;
        for (String item : setting.getList()) {
            boolean selected = setting.isSelected(item);
            int bg = selected ? 0xFF5566CC : 0x88161616;
            int textW = client.textRenderer.getWidth(item);
            context.fill((int)(x + 64 - textW), (int)(y + y2 + 3), (int)(x + 65 + 2), (int)(y + y2 + 11), bg);
            context.drawText(client.textRenderer, item, (int)(x + 64 - textW), (int)(y + y2 + 5), 0xFFD4D6E1, false);
            y2 += 10;
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        float y2 = 5;
        for (String text : setting.getList()) {
            int textW = client.textRenderer.getWidth(text);
            if (mouseX >= x + 64 - textW && mouseX <= x + 64 && mouseY >= y + y2 + 5 && mouseY <= y + y2 + 13) {
                List<String> selected = new ArrayList<>(setting.getSelected());
                if (selected.contains(text)) selected.remove(text);
                else {
                    selected.add(text);
                    selected.sort(Comparator.comparingInt(setting.getList()::indexOf));
                }
                setting.setSelected(selected);
            }
            y2 += 10;
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, double button) {}

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {}

    @Override
    public float getFullHeight() { return height; }
}
