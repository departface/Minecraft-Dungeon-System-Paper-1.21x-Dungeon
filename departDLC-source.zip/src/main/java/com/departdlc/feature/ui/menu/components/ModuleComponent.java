package com.departdlc.feature.ui.menu.components;

import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import com.departdlc.feature.module.Module;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.*;
import com.departdlc.feature.ui.menu.components.impl.*;

import java.util.ArrayList;

public class ModuleComponent {
    private float x = 0, y = 0;
    private final ArrayList<SettingComponent> settings = new ArrayList<>();
    private final Module feature;
    private boolean binding = false;
    public boolean extended = false;

    public ModuleComponent(Module feature) {
        this.feature = feature;
        feature.getSettings().forEach(s -> {
            SettingComponent sc = getSetting(s);
            if (sc != null) settings.add(sc);
        });
    }

    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;

        String name = binding ? "Press key..." : feature.getName();

        boolean hovered = mouseX >= x && mouseX <= x + 78 && mouseY >= y && mouseY <= y + 14;
        if (hovered) {
            context.fill((int)x + 1, (int)y, (int)x + 79, (int)y + 14, 0x554A5560);
        }

        int color = feature.isState() ? 0xFF8899FF : 0xFFD4D6E1;
        context.drawText(client.textRenderer, name, (int)(x + 4), (int)(y + 3), color, false);

        if (extended) {
            float settingsY = y + 16;
            for (SettingComponent settingComponent : settings) {
                settingComponent.render(context, x + 2, settingsY, mouseX, mouseY, partialTicks);
                settingsY += settingComponent.getFullHeight();
            }
        }
    }

    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        if (mouseX >= x && mouseX <= x + 78 && mouseY >= y && mouseY <= y + 14) {
            if (mouseButton == 0) feature.toggle();
            if (mouseButton == 1) extended = !extended;
            if (mouseButton == 2) binding = !binding;
        }
        if (extended) {
            for (SettingComponent s : settings) {
                s.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
    }

    public void mouseReleased(double mouseX, double mouseY, double button) {
        if (extended) settings.forEach(p -> p.mouseReleased(mouseX, mouseY, button));
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding) {
            if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                feature.setKey(-1);
            } else {
                feature.setKey(keyCode);
            }
            binding = false;
        }
        if (extended) settings.forEach(p -> p.keyPressed(keyCode, scanCode, modifiers));
    }

    public SettingComponent getSetting(Setting s) {
        if (s instanceof BooleanSetting) return new BooleanSettingComponent(s);
        if (s instanceof SliderSetting) return new SliderSettingComponent(s);
        if (s instanceof ModeSetting) return new ModeSettingComponent(s);
        if (s instanceof ModeListSetting) return new ModeListSettingComponent(s);
        if (s instanceof BindSetting) return new BindSettingComponent(s);
        return null;
    }

    public float getHeight() {
        float height = 0;
        for (SettingComponent e : settings) height += e.getFullHeight();
        return height;
    }
}
