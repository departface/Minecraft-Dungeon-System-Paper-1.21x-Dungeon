package com.departdlc.feature.ui.menu.components.impl;

import net.minecraft.client.gui.DrawContext;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.ModeSetting;
import com.departdlc.feature.ui.menu.components.SettingComponent;

public class ModeSettingComponent extends SettingComponent {
    private final ModeSetting setting;
    private float x = 0, y = 0, height = 0;

    public ModeSettingComponent(Setting s) {
        super(s);
        setting = (ModeSetting) s;
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;
        height = setting.getList().size() * 10 + 15;

        context.drawText(client.textRenderer, setting.getName(), (int)x, (int)(y - 1), 0xFFD4D6E1, false);

        float y2 = 3;
        for (String mode : setting.getList()) {
            boolean selected = mode.equals(setting.getSelected());
            int bg = selected ? 0xFF5566CC : 0x88161616;
            int textW = client.textRenderer.getWidth(mode);
            context.fill((int)(x + 73 - textW), (int)(y + y2 + 2), (int)(x + 77 - textW + textW + 4), (int)(y + y2 + 11), bg);
            context.drawText(client.textRenderer, mode, (int)(x + 75 - textW), (int)(y + y2 + 5), 0xFFFFFFFF, false);
            y2 += 10;
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        float y2 = 3;
        for (String mode : setting.getList()) {
            int textW = client.textRenderer.getWidth(mode);
            if (mouseX >= x + 75 - textW && mouseX <= x + 75 && mouseY >= y + y2 + 5 && mouseY <= y + y2 + 13)
                setting.setSelected(mode);
            y2 += 10;
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, double button) {}

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {}

    @Override
    public float getFullHeight() { return height; }
}
