package com.departdlc.feature.ui.menu.components.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.RangeSetting;
import com.departdlc.feature.ui.menu.components.SettingComponent;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class RangeSettingComponent extends SettingComponent {
    private final RangeSetting setting;
    private boolean dragMin = false, dragMax = false;
    private float x = 0, y = 0;

    public RangeSettingComponent(Setting s) {
        super(s);
        setting = (RangeSetting) s;
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;

        context.drawText(client.textRenderer, setting.getName(), (int)x, (int)(y + 2), 0xFFD4D6E1, false);
        String valueText = String.format("%.1f-%.1f", setting.getMinValue(), setting.getMaxValue());
        context.drawText(client.textRenderer, valueText, (int)(x + 66), (int)(y + 9), 0xFFD4D6E1, false);

        context.fill((int)(x + 3), (int)(y + 10), (int)(x + 63), (int)(y + 14), 0xFF0C0C0C);

        float minX = (setting.getMinValue() - setting.getMinimum()) / (setting.getMaximum() - setting.getMinimum()) * 60;
        float maxX = (setting.getMaxValue() - setting.getMinimum()) / (setting.getMaximum() - setting.getMinimum()) * 60;

        context.fill((int)(x + 3 + minX), (int)(y + 10), (int)(x + 3 + maxX), (int)(y + 14), 0xFF5566CC);

        // Min thumb
        context.fill((int)(x + 3 + minX - 2), (int)(y + 8), (int)(x + 3 + minX + 4), (int)(y + 16), 0xFFFFFFFF);
        // Max thumb
        context.fill((int)(x + 3 + maxX - 2), (int)(y + 8), (int)(x + 3 + maxX + 4), (int)(y + 16), 0xFFFFFFFF);

        if (dragMin) {
            float v = (float) MathHelper.clamp(round((mouseX - x - 3) / 60.0 * (setting.getMaximum() - setting.getMinimum()) + setting.getMinimum(), setting.getIncrement()), setting.getMinimum(), setting.getMaxValue());
            setting.setMinValue(v);
        }
        if (dragMax) {
            float v = (float) MathHelper.clamp(round((mouseX - x - 3) / 60.0 * (setting.getMaximum() - setting.getMinimum()) + setting.getMinimum(), setting.getIncrement()), setting.getMinValue(), setting.getMaximum());
            setting.setMaxValue(v);
        }
    }

    public static double round(double num, double increment) {
        return new BigDecimal(Math.round(num / increment) * increment).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        if (mouseButton != 0) return;
        float minX = x + 3 + (setting.getMinValue() - setting.getMinimum()) / (setting.getMaximum() - setting.getMinimum()) * 60;
        float maxX = x + 3 + (setting.getMaxValue() - setting.getMinimum()) / (setting.getMaximum() - setting.getMinimum()) * 60;
        boolean onMin = mouseX >= minX - 3 && mouseX <= minX + 4 && mouseY >= y + 8 && mouseY <= y + 16;
        boolean onMax = mouseX >= maxX - 3 && mouseX <= maxX + 4 && mouseY >= y + 8 && mouseY <= y + 16;
        if (onMin && onMax) { if (Math.abs(mouseX - minX) < Math.abs(mouseX - maxX)) dragMin = true; else dragMax = true; }
        else if (onMin) dragMin = true;
        else if (onMax) dragMax = true;
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, double button) { dragMin = false; dragMax = false; }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {}

    @Override
    public float getFullHeight() { return 22f; }
}
