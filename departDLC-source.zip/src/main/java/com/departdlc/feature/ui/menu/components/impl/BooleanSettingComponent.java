package com.departdlc.feature.ui.menu.components.impl;

import net.minecraft.client.gui.DrawContext;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.BooleanSetting;
import com.departdlc.feature.ui.menu.components.SettingComponent;

public class BooleanSettingComponent extends SettingComponent {
    private final BooleanSetting setting;
    private float x = 0, y = 0;

    public BooleanSettingComponent(Setting s) {
        super(s);
        setting = (BooleanSetting) s;
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;

        context.drawText(client.textRenderer, setting.getName(), (int)x, (int)(y + 2), 0xFFD4D6E1, false);

        int checkboxColor = setting.isState() ? 0xFF8899FF : 0xFF333344;
        int textWidth = client.textRenderer.getWidth(setting.getName());
        context.fill((int)(x + textWidth + 4), (int)(y - 1), (int)(x + textWidth + 14), (int)(y + 9), checkboxColor);
        if (setting.isState()) {
            context.drawText(client.textRenderer, "✓", (int)(x + textWidth + 5), (int)(y + 1), 0xFFFFFFFF, false);
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        int textWidth = client.textRenderer.getWidth(setting.getName());
        if (mouseX >= x + textWidth + 4 && mouseX <= x + textWidth + 14 &&
            mouseY >= y - 1 && mouseY <= y + 9 && mouseButton == 0) {
            setting.set(!setting.isState());
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, double button) {}

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {}

    @Override
    public float getFullHeight() { return 15f; }
}
