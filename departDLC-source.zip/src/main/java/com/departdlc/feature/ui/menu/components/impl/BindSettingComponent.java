package com.departdlc.feature.ui.menu.components.impl;

import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import com.departdlc.feature.module.setting.Setting;
import com.departdlc.feature.module.setting.impl.BindSetting;
import com.departdlc.feature.ui.menu.components.SettingComponent;

public class BindSettingComponent extends SettingComponent {
    private final BindSetting setting;
    boolean set = false;
    private float x = 0, y = 0;

    public BindSettingComponent(Setting s) {
        super(s);
        setting = (BindSetting) s;
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        this.x = x;
        this.y = y;
        String keyName = GLFW.glfwGetKeyName(setting.getKey(), 0);
        String displayKey = set ? "Press key..." : (keyName != null ? keyName.toUpperCase() : "NONE");
        int nameW = client.textRenderer.getWidth(setting.getName());
        context.drawText(client.textRenderer, setting.getName(), (int)(x + 5), (int)(y + 2), 0xFFD4D6E1, false);
        context.fill((int)(x + nameW + 12), (int)(y - 1), (int)(x + nameW + 12 + client.textRenderer.getWidth(displayKey) + 6), (int)(y + 10), 0xFF5566CC);
        context.drawText(client.textRenderer, displayKey, (int)(x + nameW + 15), (int)(y + 2), 0xFFFFFFFF, false);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, double mouseButton) {
        int nameW = client.textRenderer.getWidth(setting.getName());
        if (mouseX >= x + nameW + 12 && mouseY >= y - 1 && mouseY <= y + 10 && mouseButton == 0)
            set = true;
        if (set && mouseButton != 0) {
            setting.setKey((int) mouseButton);
            set = false;
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, double button) {}

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (set) {
            if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                setting.setKey(-1);
            } else {
                setting.setKey(keyCode);
            }
            set = false;
        }
    }

    @Override
    public float getFullHeight() { return 15f; }
}
